
import Foundation

enum CoffeeSize: String {
    case small
    case medium
    case large
}

struct Coffee {
    var name: String
    var size: CoffeeSize
}

let size = CoffeeSize(rawValue: "small")

if let size = size {
    
    switch size {
    case .small:
        break
    case .medium:
        break
    case .large:
        break
    }
    
}

enum NumberType {
    case par
    case impar
}

func type(of number: Int) -> NumberType {
    if number % 2 == 0 {
        return .par
    }
    return .impar
}

let number = type(of: 17)
print(number)

enum Endpoint {
    case google
    case facebook
    case apple
}

extension Endpoint {
    
    var request: URLRequest {
        switch self {
        case .google:
            guard let url = URL(string: "www.google.com") else { fatalError("URL inválida") }
            return URLRequest(url: url)
        case .apple:
            guard let url = URL(string: "www.apple.com") else { fatalError("URL inválida") }
            return URLRequest(url: url)
        case .facebook:
            guard let url = URL(string: "www.facebook.com") else { fatalError("URL inválida") }
            return URLRequest(url: url)
        }
    }
}

func request(_ endpoint: Endpoint) {
    
    let request = endpoint.request
    
    URLSession.shared.dataTask(with: request)
    
}

request(.facebook)


enum Traveler {
    case male(String)
    case female(String)
}

func TypeTraveler(gender: String, from place: String) -> Traveler {
    if gender == "male" {
        return .male(place)
    }
    return .female(place)
}

let aTraveler = TypeTraveler(gender: "female", from: "Francia")

switch aTraveler {
case .male(let place):
    print("A man traveling from: \(place)")
case .female(let place):
    print("A woman traveling from: \(place)")
}
